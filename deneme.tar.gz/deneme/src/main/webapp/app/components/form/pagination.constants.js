(function() {
    'use strict';

    angular
        .module('stajProjeApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
