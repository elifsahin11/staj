/**
 * Service layer beans.
 */
package com.staj.proje.service;
