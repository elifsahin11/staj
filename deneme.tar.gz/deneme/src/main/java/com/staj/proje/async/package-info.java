/**
 * Async helpers.
 */
package com.staj.proje.async;
