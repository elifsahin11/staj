/**
 * JPA domain objects.
 */
package com.staj.proje.domain;
