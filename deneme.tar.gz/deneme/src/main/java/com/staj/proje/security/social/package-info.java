/**
 * Spring social configuration.
 */
package com.staj.proje.security.social;
